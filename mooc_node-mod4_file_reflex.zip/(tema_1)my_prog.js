'use strict' 

    let x = 1; 
    this.y = 2; 

    y = 3;

    console.log(this.y);